print('Binance AI Bot starter')
